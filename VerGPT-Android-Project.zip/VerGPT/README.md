# VerGPT — Android offline AI chat

Android-приложение на Kotlin + Jetpack Compose с локальным ИИ через LiteRT-LM.

## Важно
APK не включает саму языковую модель. После установки нужно один раз скачать совместимую модель LiteRT-LM (`.litertlm`) и импортировать её в приложении. После успешной загрузки модели чат может работать без интернета.

## Получить APK через GitHub Actions
Подробная инструкция на русском — `BUILD_APK_ONLINE_RU.txt`.

Коротко: загрузите весь проект в GitHub, откройте Actions, запустите workflow `Build VerGPT APK`, затем скачайте артефакт `VerGPT-debug-apk`.

## Локальная сборка
Откройте папку проекта в Android Studio и выполните Build → Build APK(s). APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

## Технические параметры
- Kotlin + Jetpack Compose
- LiteRT-LM Android runtime
- minSdk 24 (Android 7.0)
- targetSdk 35
- JDK 17 / Gradle 8.13
