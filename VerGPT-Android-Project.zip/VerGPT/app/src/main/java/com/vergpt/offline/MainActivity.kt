package com.vergpt.offline

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Accent = Color(0xFF8B7CFF)
private val MainText = Color(0xFFF2F1F8)
private val Muted = Color(0xFF9B9BAA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VerGptApp() }
    }
}

data class ChatLine(val id: Long, val text: String, val fromUser: Boolean)

@Composable
fun VerGptApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("vergpt", 0) }
    var modelPath by remember { mutableStateOf(prefs.getString("model_path", null)) }
    var status by remember { mutableStateOf(if (modelPath == null) "Добавь локальную модель" else "Модель выбрана · загружаю…") }
    var ready by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val messages = remember {
        mutableStateListOf<ChatLine>().apply {
            runCatching {
                val saved = JSONArray(prefs.getString("chat_history", "[]"))
                for (i in 0 until saved.length()) {
                    val item = saved.getJSONObject(i)
                    add(ChatLine(item.getLong("id"), item.getString("text"), item.getBoolean("user")))
                }
            }
        }
    }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val dispatcher = remember { executor.asCoroutineDispatcher() }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.Main) }
    var engine by remember { mutableStateOf<Engine?>(null) }
    var conversation by remember { mutableStateOf<Conversation?>(null) }

    fun loadModel(path: String) {
        ready = false
        status = "Загружаю модель… первый запуск может занять время"
        scope.launch {
            try {
                withContext(dispatcher) {
                    conversation?.close(); conversation = null
                    engine?.close(); engine = null
                    val newEngine = Engine(EngineConfig(modelPath = path, backend = Backend.CPU(), cacheDir = context.cacheDir.path))
                    newEngine.initialize()
                    engine = newEngine
                    conversation = newEngine.createConversation(
                        ConversationConfig(systemInstruction = Contents.of("Ты — VerGPT, полезный ИИ-помощник. Отвечай на русском языке, ясно и дружелюбно. Если не знаешь ответа, честно скажи об этом."))
                    )
                }
                ready = true
                status = "Готов к работе · офлайн"
                error = null
            } catch (e: Exception) {
                status = "Не удалось загрузить модель"
                error = e.message ?: "Проверь файл модели и совместимость."
            }
        }
    }

    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    status = "Копирую файл модели…"
                    val target = File(context.filesDir, "vergpt-model.litertlm")
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri).use { inputStream ->
                            requireNotNull(inputStream) { "Не удалось открыть файл" }.use { src -> target.outputStream().use { dst -> src.copyTo(dst) } }
                        }
                    }
                    modelPath = target.absolutePath
                    prefs.edit().putString("model_path", target.absolutePath).apply()
                } catch (e: Exception) {
                    status = "Ошибка импорта модели"
                    error = e.message
                }
            }
        }
    }

    fun sendMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty() || !ready || busy) return
        input = ""
        messages.add(ChatLine(System.currentTimeMillis(), prompt, true))
        val answerId = System.currentTimeMillis() + 1
        messages.add(ChatLine(answerId, "", false))
        busy = true
        scope.launch {
            try {
                withContext(dispatcher) {
                    conversation!!.sendMessageAsync(prompt).collect { chunk ->
                        withContext(Dispatchers.Main) {
                            val index = messages.indexOfLast { it.id == answerId }
                            if (index >= 0) messages[index] = messages[index].copy(text = messages[index].text + chunk.toString())
                        }
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "Ошибка генерации ответа"
            } finally { busy = false }
        }
    }

    LaunchedEffect(modelPath) { if (!modelPath.isNullOrBlank() && File(modelPath!!).exists()) loadModel(modelPath!!) }
    LaunchedEffect(messages.size, messages.lastOrNull()?.text) {
        val saved = JSONArray()
        messages.forEach { line ->
            saved.put(JSONObject().put("id", line.id).put("text", line.text).put("user", line.fromUser))
        }
        prefs.edit().putString("chat_history", saved.toString()).apply()
    }
    DisposableEffect(Unit) {
        onDispose {
            scope.launch {
                withContext(dispatcher) {
                    conversation?.close(); conversation = null
                    engine?.close(); engine = null
                }
                dispatcher.close()
                executor.shutdown()
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Accent, onBackground = MainText, onSurface = MainText)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(Accent, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                    Text("V", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("VerGPT", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(status, color = Muted, fontSize = 11.sp)
                }
                TextButton(onClick = { messages.clear(); prefs.edit().remove("chat_history").apply(); error = null }) { Text("Новый чат", color = Accent) }
            }
            HorizontalDivider(color = Color(0xFF292B35))
            if (messages.isEmpty()) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Привет! Я VerGPT", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Локальный ИИ-помощник. После установки модели могу работать без интернета.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp)
                    Spacer(Modifier.height(22.dp))
                    Button(onClick = { pickModel.launch(arrayOf("*/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Выбрать модель ИИ") }
                    Text("Нужен файл .litertlm", color = Muted, fontSize = 11.sp)
                }
            } else {
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(messages, key = { it.id }) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                            Box(Modifier.widthIn(max = 310.dp).background(if (line.fromUser) Color(0xFF34304F) else Panel, RoundedCornerShape(18.dp)).padding(horizontal = 15.dp, vertical = 11.dp)) {
                                Text(line.text.ifEmpty { if (busy && !line.fromUser) "Думаю…" else "" }, color = MainText, fontSize = 15.sp, lineHeight = 21.sp)
                            }
                        }
                    }
                }
            }
            if (error != null) Text(error!!, color = Color(0xFFFF8A8A), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { pickModel.launch(arrayOf("*/*")) }) { Text("＋", color = Accent, fontSize = 24.sp) }
                Row(Modifier.weight(1f).background(Panel, CircleShape).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), enabled = ready && !busy, textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 15.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent), singleLine = true, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { sendMessage() }), decorationBox = { inner -> if (input.isEmpty()) Text(if (ready) "Написать сообщение…" else "Сначала выбери модель ИИ", color = Muted, fontSize = 14.sp); inner() })
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { sendMessage() }, enabled = ready && !busy && input.isNotBlank(), modifier = Modifier.size(46.dp).background(if (ready && !busy && input.isNotBlank()) Accent else Color(0xFF383844), CircleShape)) {
                    Text("↑", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
